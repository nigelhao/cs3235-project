# help with debugging
./target/debug/bin_client \
   ./bin_client/policies/seccomp_client.json \
   ./tests/nakamoto_config1_alone \
   ./bin_client/policies/seccomp_nakamoto.json \
   ./tests/_secrets/Wallet.A.json \
   ./bin_client/policies/seccomp_client.json \
