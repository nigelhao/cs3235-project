# stop all four instances started by run_four.sh
tmux kill-session -t nakafour
/bin/rm botpipeA
