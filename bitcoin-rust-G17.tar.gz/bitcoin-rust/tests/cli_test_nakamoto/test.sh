cd ../../../
cat ./tests/cli_test_nakamoto/stdio.input | ./target/debug/bin_nakamoto >./tests/nakamoto_cli_test/stdio.output